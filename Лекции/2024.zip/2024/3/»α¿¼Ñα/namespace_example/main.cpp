#include <iostream>
#include "utils.h"

using namespace std;
using namespace super;
using utils::world;

int main(){
    int* pi = NULL;
    cout << utils::hellow() << ' ' << world() << endl;
    return 0;
}