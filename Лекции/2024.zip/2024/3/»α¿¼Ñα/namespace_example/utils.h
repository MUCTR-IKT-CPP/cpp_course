#ifndef UTILS_H_EXAMPLES
#define UTILS_H_EXAMPLES
#include <string>

namespace super{
    namespace utils{
        std::string hellow();
        std::string world();
    }
}


#endif