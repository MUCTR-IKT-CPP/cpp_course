#include "utils.h"

std::string super::utils::hellow(){
    return "hellow";
}

std::string super::utils::world(){
    return "world";
}