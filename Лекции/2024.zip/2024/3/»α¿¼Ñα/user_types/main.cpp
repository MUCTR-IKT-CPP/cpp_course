#include <iostream>
#include <cstdlib>
#include <ctime>

typedef unsigned short int usi;
typedef unsigned short int usi; 

int main(){
    int n = 10;
    int
    return 0;
}
