#include <iostream>
#include <memory>

using namespace std;



int main (){

    // if(<условие>){
    // // Блок кода если условие истинно
    // }else if(<условие 2>){
    // // Блок кода если первое условие ложно а второе условие истино
    // }else{
    // // Блок кода если все условия ложны
    // }
    // switch(<проверяемая переменная>){
    // case <первое значение>:
    //     // блок кода если переменная имеет значение 1
    //     break;
    // case <второе значение>:
    //     // блок кода если переменная имеет значение 2
    //     break;
    // case <третье значение>:
    //     // блок кода если переменная имеет значение 3, не завершается и выполняет следующий по порядку блок, до тех пор пока не встретит break
    // case <четвертое значение>:
    //     // блок кода если переменная имеет значение 4
    //     break;
    // default:
    //     // блок кода если переменная не имеет ни одного из представленных значений.
    //     break;
    // }
    // bool b = true;
    // bool c = true;
    // if(b){
    //     cout << "in if" << endl;
    // }else if(c){
    //     cout << "in else if" << endl; // даже при том условие истинное
    // }else{
    //     cout << "in else" << endl;
    // }

    // const char top_direction = 't';
    // char direction = 't';

    // switch(direction){
    //     case top_direction:
    //         cout << "To top direction" << endl;
    //         break;
    //     default:
    //         cout << "Undefined direction" << endl;
    //         break;
    // }
    // const int N = 10;
    // int array[N] {10, 4, 6, 8, 3, 9, 4, 5, 9, 40};
    // int sum {0};
    // for(int i = 0; i < N; i++){
    //     sum += array[i];
    // }
    // cout << sum << endl;
    
    return 0;
}

