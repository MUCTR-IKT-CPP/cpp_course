template <typename T>
T* maximum(const T& a, const T* b)